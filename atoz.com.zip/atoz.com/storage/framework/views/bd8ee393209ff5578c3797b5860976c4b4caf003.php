<?php $__env->startSection('main'); ?>
	<div id="siswa">
		<h2>Success!</h2>
		<?php echo Form::open(['method'=>'PATCH', 'action'=>['TransactionController@pay', $transaction->id]]); ?>

		<table class="table table-striped">
			<tr>
				<th>Order No</th>
				<td><?php echo e($transaction->order_number); ?></td>
			</tr>
			<tr>
				<th>Total</th>
				<td><?php echo e($transaction->shopping_type == 'product' ? $transaction->price : $transaction->balance->balance_value); ?></td>
			</tr>
			<tr>
				<th>&nbsp;</th>
				<td>&nbsp;</td>
			</tr>
			<?php if($transaction->shopping_type == 'product'): ?>
			<tr>
				<th><?php echo e($transaction->product); ?> that costs <?php echo e($transaction->price); ?> will be shipped to :<br /><?php echo e($transaction->shipping_address); ?><br /><p>Only after you pay</p></th>
				<td></td>
			</tr>
			<?php endif; ?>
		</table>
		<?php echo Form::submit('Pay now', ['class'=>'btn btn-primary form-control']); ?>

		<?php echo Form::close(); ?>

	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
	<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
			
			
			
			
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>