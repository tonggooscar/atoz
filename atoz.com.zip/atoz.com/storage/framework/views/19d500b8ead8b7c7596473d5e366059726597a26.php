<nav class="navbar navbar-default">
<div class="container-fluid">
	<div class="navbar-header">
		<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1"
		aria-expanded="false">
			<span class="sr-only">Atoz navigation</span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		</button>
		<a class="navbar-brand" href="<?php echo e(url('/')); ?>">Atoz</a>
	</div>
	<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
		<ul class="nav navbar-nav">
		<?php if(Auth::check()): ?>
			<?php if(!empty($page) && $page=='prepaid_balance'): ?>
				<li class="active"><a href="<?php echo e(url('prepaid_balance')); ?>">Prepaid Balance</a></li>
				<span class="sr-only">(current)</span></a></li>
			<?php else: ?>
				<li><a href="<?php echo e(url('prepaid_balance')); ?>">Prepaid Balance</a></li>
			<?php endif; ?>
			
			<?php if(!empty($page) && $page=='product'): ?>
				<li class="active"><a href="<?php echo e(url('/product')); ?>">Product</a></li>
				<span class="sr-only">(current)</span></a></li>
			<?php else: ?>
				<li><a href="<?php echo e(url('product')); ?>">Product</a></li>
			<?php endif; ?>
			
			<?php if(!empty($page) && $page=='order'): ?>
				<li class="active"><a href="<?php echo e(url('/order')); ?>">Order</a></li>
				<span class="sr-only">(current)</span></a></li>
			<?php else: ?>
				<li><a href="<?php echo e(url('order')); ?>">Order</a></li>
			<?php endif; ?>
		<?php endif; ?>
		</ul>
		<ul class="nav navbar-nav navbar-right">
			<?php if(Auth::check()): ?>
				<li><a href="<?php echo e(url('logout')); ?>" title="Click here to Log Out"><?php echo e(Auth::user()->name); ?></a></li>
			<?php else: ?>
			<li><a href="<?php echo e(url('login')); ?>">Login</a></li>
			<?php endif; ?>
			<li class="dropdown"></li>
		</u>
	</div>
</div>
</nav>
	






