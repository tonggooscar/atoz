<?php $__env->startSection('main'); ?>
	<div id="prepaid_balance">
		<h2>Prepaid Balance</h2>
		
		
		<?php echo Form::open(['url'=>'transaction']); ?>

		
			<?php echo Form::hidden('shopping_type', 'prepaid'); ?>

		
			<?php if($errors->any()): ?>
				<div class="form-group <?php echo e($errors->has('mobile_number') ? 'has-error' : 'has-success'); ?>">
			<?php else: ?>
				<div class="form-group">
			<?php endif; ?>
				<?php echo Form::label('mobile_number', 'Mobile Number : ', ['class'=>'control-label']); ?>

				<?php echo Form::text('mobile_number', null, ['class'=>'form-control', 'placeholder'=>'Mobile Number']); ?>

				<?php if($errors->has('mobile_number')): ?>
					<span class="help-block"><?php echo e($errors->first('mobile_number')); ?></span>
				<?php endif; ?>
			</div>
			
			<?php if($errors->any()): ?>
				<div class="form-group <?php echo e($errors->has('id_balance') ? 'has-error' : 'has-success'); ?>">
			<?php else: ?>
				<div class="form-group">
			<?php endif; ?>
				<?php echo Form::label('id_balance', 'Balance : ', ['class'=>'control-label']); ?>

				<?php if(count($list_balance)): ?>
					<?php echo Form::select('id_balance', $list_balance, null, ['class'=>'form-control', 'id'=>'id_balance', 'placeholder'=>'Choose Balance']); ?>

				<?php else: ?>
					<p>Nothing Balance, please insert the data before.</p>
				<?php endif; ?>
				<?php if($errors->has('id_balance')): ?>
					<span class="help-block"><?php echo e($errors->first('id_balance')); ?></span>
				<?php endif; ?>
			</div>

			<?php echo Form::submit('Submit', ['class'=>'btn btn-primary form-control']); ?>

		
		<?php echo Form::close(); ?>

	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
	
<?php $__env->stopSection(); ?>
				
				
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>