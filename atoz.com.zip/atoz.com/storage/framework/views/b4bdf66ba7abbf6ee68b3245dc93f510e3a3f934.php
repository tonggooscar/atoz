<?php $__env->startSection('main'); ?>
	<div id="order">
		<h2>Order</h2>
		<?php echo $__env->make('transaction.form_search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		
		<?php if(!empty($transaction_list)): ?>
			<table class="table">
				<thead>
					<tr>
						<th>Order Number</th>
						<th>Price</th>
						<th>Description</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody>
					<?php $__currentLoopData = $transaction_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($transaction->order_number); ?></td>
						<td><?php echo e($transaction->shopping_type == 'product' ? $transaction->price : $transaction->balance->balance_value); ?></td>
						<td><?php echo e($transaction->shopping_type == 'product' ? $transaction->product.' that costs '.$transaction->price : $transaction->balance->balance_value.'  for '.$transaction->mobile_number); ?></td>
						<td>
							<div class="box-button">
								<?php if($transaction->status=='Waiting'): ?>
									<div class="box-button">
										<?php echo Form::open(['method'=>'PATCH', 'action'=>['TransactionController@pay', $transaction->id]]); ?>

										<?php echo Form::submit('Pay now', ['class'=>'btn btn-primary']); ?>

										<?php echo Form::close(); ?>

									</div>
								<?php elseif($transaction->status=='Success'): ?>
									<?php if($transaction->shopping_type=='product'): ?>
										<?php echo e($transaction->shipping_code); ?>

									<?php else: ?>
										<?php echo e('Success'); ?>

									<?php endif; ?>
								<?php endif; ?>
							</div>
						</td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
		<?php else: ?>
			<p>Nothing Order.</p>
		<?php endif; ?>
		
		<div class="table-nav">
			<div class="count-data">
				<strong>Total Order : <?php echo e($count_transaction); ?></strong>
			</div>
			<div class="paging">
				<?php echo e($transaction_list->links()); ?>

			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
	<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>