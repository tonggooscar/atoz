<?php $__env->startSection('main'); ?>
	<div id="product">
		<h2>Product Page</h2>
		
		<?php echo Form::open(['url'=>'transaction']); ?>

		
			<?php echo Form::hidden('shopping_type', 'product'); ?>

			
			<?php if($errors->any()): ?>
				<div class="form-group <?php echo e($errors->has('product') ? 'has-error' : 'has-success'); ?>">
			<?php else: ?>
				<div class="form-group">
			<?php endif; ?>
				<?php echo Form::label('product', 'Product : ', ['class'=>'control-label']); ?>

				<?php echo Form::textarea('product', null, ['id' => 'product', 'rows' => 4, 'cols' => 54, 'placeholder'=>'Product']); ?>

				<?php if($errors->has('product')): ?>
					<span class="help-block"><?php echo e($errors->first('product')); ?></span>
				<?php endif; ?>
			</div>
			
			<?php if($errors->any()): ?>
				<div class="form-group <?php echo e($errors->has('shipping_address') ? 'has-error' : 'has-success'); ?>">
			<?php else: ?>
				<div class="form-group">
			<?php endif; ?>
				<?php echo Form::label('shipping_address', 'Shipping Address : ', ['class'=>'control-label']); ?>

				<?php echo Form::textarea('shipping_address', null, ['id' => 'shipping_address', 'rows' => 4, 'cols' => 54, 'placeholder'=>'Shipping Address']); ?>

				<?php if($errors->has('shipping_address')): ?>
					<span class="help-block"><?php echo e($errors->first('shipping_address')); ?></span>
				<?php endif; ?>
			</div>
			
			<?php if($errors->any()): ?>
				<div class="form-group <?php echo e($errors->has('price') ? 'has-error' : 'has-success'); ?>">
			<?php else: ?>
				<div class="form-group">
			<?php endif; ?>
				<?php echo Form::label('price', 'Price : ', ['class'=>'control-label']); ?>

				<?php echo Form::text('price', null, ['class'=>'form-control', 'placeholder'=>'Price']); ?>

				<?php if($errors->has('price')): ?>
					<span class="help-block"><?php echo e($errors->first('price')); ?></span>
				<?php endif; ?>
			</div>

			<?php echo Form::submit('Submit', ['class'=>'btn btn-primary form-control']); ?>

		
		<?php echo Form::close(); ?>

	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
	
<?php $__env->stopSection(); ?>
				
				
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>