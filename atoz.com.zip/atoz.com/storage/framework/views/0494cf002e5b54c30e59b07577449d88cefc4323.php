<?php $__env->startSection('main'); ?>
	<div id="homepage">
		<h2>Homepage</h2>
		<p>Welcome to Atoz.com</p>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
	<div id="footer">
		<p>&copy; 2019<p>
	</div>
<?php $__env->stopSection(); ?>
	
	
	
	
	
	
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>