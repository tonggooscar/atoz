<div id="pencarian">
	<?php echo Form::open(['url' => 'order', 'method' => 'GET', 'id' => 'form-search']); ?>

	
		<div class="row">
			<div class="col-md2">
				<div class="input-group">
					<?php echo Form::text('keyword', (!empty($keyword)) ? $keyword : null, ['class' => 'form-control', 'placeholder' => 'Enter the keyword']); ?>

					<span class="input-group-btn">
						<?php echo Form::button('Search', ['class' => 'btn btn-default', 'type' => 'submit']); ?>

					</span>
				</div>
			</div>
		</div>

	<?php echo Form::close(); ?>

</div>

