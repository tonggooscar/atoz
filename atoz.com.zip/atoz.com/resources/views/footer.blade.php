<div id="footer">
	<p>&copy; 2019 Powered by Atoz</p>
</div>